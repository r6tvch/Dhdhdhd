// Downloads the Google Fonts used by the game and embeds them locally, so the app works offline.
const fs=require('fs'),path=require('path');
const html=path.join(__dirname,'game','index.html');
(async()=>{
  try{
    let src=fs.readFileSync(html,'utf8');
    const m=src.match(/<link[^>]+href="(https:\/\/fonts\.googleapis\.com\/css2[^"]+)"[^>]*>/);
    if(!m){console.log('no google font link');return}
    const url=m[1].replace(/&amp;/g,'&');
    const ua={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124 Safari/537.36'};
    let css=await (await fetch(url,{headers:ua})).text();
    const dir=path.join(__dirname,'game','fonts');fs.mkdirSync(dir,{recursive:true});
    const urls=[...new Set([...css.matchAll(/url\((https:[^)]+)\)/g)].map(x=>x[1]))];
    let i=0;
    for(const u of urls){
      const name='f'+(i++)+path.extname(new URL(u).pathname);
      fs.writeFileSync(path.join(dir,name),Buffer.from(await (await fetch(u)).arrayBuffer()));
      css=css.split(u).join('fonts/'+name);
    }
    fs.writeFileSync(path.join(__dirname,'game','fonts.css'),css);
    src=src.replace(m[0],'<link rel="stylesheet" href="fonts.css">');
    src=src.replace(/<link[^>]+fonts\.gstatic\.com[^>]*>/g,'').replace(/<link[^>]+preconnect[^>]+fonts\.googleapis\.com[^>]*>/g,'');
    fs.writeFileSync(html,src);
    console.log('embedded',urls.length,'font files');
  }catch(e){console.log('font embedding skipped:',e.message)}
})();
